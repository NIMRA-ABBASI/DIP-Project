import cv2
import os
import argparse
import time
from datetime import datetime

def draw_text_on_frame(frame, text, position, font_scale=0.7, color=(255, 255, 255), thickness=1, bg_color=(0,0,0), padding=5):
    """Helper function to draw text with a background on the frame."""
    font = cv2.FONT_HERSHEY_SIMPLEX
    text_size, _ = cv2.getTextSize(text, font, font_scale, thickness)
    text_w, text_h = text_size
    
    # Add padding to background
    bg_x1 = position[0] - padding
    bg_y1 = position[1] - text_h - padding 
    bg_x2 = position[0] + text_w + padding
    bg_y2 = position[1] + padding
    
    # Ensure background is within frame boundaries (optional, but good practice)
    bg_x1 = max(bg_x1, 0)
    bg_y1 = max(bg_y1, 0)
    bg_x2 = min(bg_x2, frame.shape[1])
    bg_y2 = min(bg_y2, frame.shape[0])

    # Draw background rectangle
    if bg_color is not None:
        cv2.rectangle(frame, (bg_x1, bg_y1), (bg_x2, bg_y2), bg_color, -1)
    
    # Draw text
    cv2.putText(frame, text, position, font, font_scale, color, thickness, cv2.LINE_AA)


def main(args):
    # --- Camera Setup ---
    cap = cv2.VideoCapture(args.camera_index, cv2.CAP_DSHOW) # CAP_DSHOW for Windows, might improve performance/stability
    if not cap.isOpened():
        print(f"Error: Could not access camera at index {args.camera_index}.")
        return

    # Set camera resolution (if specified)
    if args.width and args.height:
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, args.width)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, args.height)
        print(f"Attempted to set resolution to: {args.width}x{args.height}")

    actual_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    actual_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    print(f"Actual camera resolution: {actual_width}x{actual_height}")

    # --- Output Folder ---
    if not os.path.exists(args.output_folder):
        try:
            os.makedirs(args.output_folder)
            print(f"Created output folder: {args.output_folder}")
        except OSError as e:
            print(f"Error creating output folder '{args.output_folder}': {e}")
            cap.release()
            return

    # --- Variables for Loop ---
    fps = 0
    frame_count = 0
    start_time = time.time()
    
    countdown = -1  # -1 means no countdown active, 3, 2, 1, 0 for countdown
    countdown_timer_start = 0
    
    capture_message = ""
    capture_message_display_time = 0
    
    images_captured_session = 0
    
    print("\n--- Controls ---")
    print("SPACE: Start 3-sec countdown & capture")
    print("C:     Capture immediately (no countdown)")
    print("Q:     Quit")
    print("----------------\n")

    window_name = "Advanced Camera Capture"

    while True:
        ret, frame = cap.read()
        if not ret:
            print("Failed to read from camera. Exiting.")
            break

        display_frame = frame.copy()
        current_time = time.time()

        # --- FPS Calculation ---
        frame_count += 1
        if current_time - start_time >= 1:
            fps = frame_count / (current_time - start_time)
            frame_count = 0
            start_time = current_time
        
        # --- On-Screen Display (OSD) ---
        y_offset = 30
        draw_text_on_frame(display_frame, f"Res: {actual_width}x{actual_height}", (10, y_offset))
        y_offset += 30
        draw_text_on_frame(display_frame, f"FPS: {fps:.2f}", (10, y_offset))
        y_offset += 30
        draw_text_on_frame(display_frame, f"Captured: {images_captured_session}", (10, y_offset))
        
        # Instructions
        draw_text_on_frame(display_frame, "SPACE: Countdown | C: Capture | Q: Quit", (10, actual_height - 20), font_scale=0.6)

        # --- Countdown Logic ---
        if countdown > 0:
            elapsed_since_countdown_start = current_time - countdown_timer_start
            if elapsed_since_countdown_start >= 1: # Decrement every second
                countdown -=1
                countdown_timer_start = current_time # Reset timer for next second
            
            if countdown > 0: # Still counting down
                draw_text_on_frame(display_frame, str(countdown), 
                                   (actual_width // 2 - 30, actual_height // 2 - 50), 
                                   font_scale=5, color=(0, 255, 255), thickness=5, bg_color=None)
        
        elif countdown == 0: # Countdown finished, capture image
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")[:-3] # Milliseconds
            filename = f"{args.filename_prefix}{timestamp}.{args.format}"
            save_path = os.path.join(args.output_folder, filename)
            
            try:
                if args.format == "jpg":
                    cv2.imwrite(save_path, frame, [cv2.IMWRITE_JPEG_QUALITY, args.jpg_quality])
                else:
                    cv2.imwrite(save_path, frame)
                capture_message = f"Saved: {filename}"
                images_captured_session +=1
                print(capture_message)
            except Exception as e:
                capture_message = f"Error saving: {e}"
                print(capture_message)
            
            capture_message_display_time = current_time
            countdown = -1 # Reset countdown

        # --- Display Capture Message ---
        if capture_message and (current_time - capture_message_display_time < 2): # Display for 2 seconds
            draw_text_on_frame(display_frame, capture_message, (10, actual_height - 50), font_scale=0.6, color=(0,255,0))
        elif capture_message and (current_time - capture_message_display_time >= 2):
            capture_message = ""


        cv2.imshow(window_name, display_frame)
        key = cv2.waitKey(1) & 0xFF

        # --- Key Handling ---
        if key == ord('q'):
            print("Quitting...")
            break
        elif key == 32:  # SPACE key for countdown capture
            if countdown == -1 : # Start countdown only if not already active
                print("Starting 3-second countdown for capture...")
                countdown = 3
                countdown_timer_start = current_time
        elif key == ord('c'): # 'c' for immediate capture
            if countdown != -1:
                print("Countdown in progress, cannot start immediate capture. Wait or press Q.")
            else:
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")[:-3]
                filename = f"{args.filename_prefix}{timestamp}.{args.format}"
                save_path = os.path.join(args.output_folder, filename)
                try:
                    if args.format == "jpg":
                        cv2.imwrite(save_path, frame, [cv2.IMWRITE_JPEG_QUALITY, args.jpg_quality])
                    else:
                        cv2.imwrite(save_path, frame)
                    capture_message = f"Saved: {filename}"
                    images_captured_session += 1
                    print(capture_message)
                except Exception as e:
                    capture_message = f"Error saving: {e}"
                    print(capture_message)
                capture_message_display_time = current_time


    # --- Cleanup ---
    cap.release()
    cv2.destroyAllWindows()
    print(f"Session ended. {images_captured_session} image(s) captured in '{args.output_folder}'.")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Advanced Camera Capture Utility")
    parser.add_argument("--camera-index", type=int, default=0, help="Index of the camera to use (default: 0)")
    parser.add_argument("--width", type=int, default=None, help="Desired camera frame width (e.g., 1280)")
    parser.add_argument("--height", type=int, default=None, help="Desired camera frame height (e.g., 720)")
    parser.add_argument("--output-folder", type=str, default="captured_images", help="Folder to save captured images")
    parser.add_argument("--filename-prefix", type=str, default="capture_", help="Prefix for saved image filenames")
    parser.add_argument("--format", type=str, default="png", choices=["png", "jpg"], help="Image format for saving (png or jpg)")
    parser.add_argument("--jpg-quality", type=int, default=95, choices=range(0, 101), metavar="[0-100]", help="JPEG quality if format is jpg (0-100, default: 95)")
    
    cli_args = parser.parse_args()
    main(cli_args)


    #python barcode_camera.py --camera-index 0 --width 1920 --height 1080 --output-folder my_captures --format jpg --jpg-quality 90