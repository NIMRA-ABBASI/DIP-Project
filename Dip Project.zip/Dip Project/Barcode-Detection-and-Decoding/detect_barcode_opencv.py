import numpy as np
import argparse
import cv2

def debug_show(window_name, image, show_flag, scale_factor=0.5):
    """Helper function to display intermediate images if show_flag is True."""
    if show_flag:
        if image is None:
            print(f"Warning: Image for window '{window_name}' is None.")
            return

        img_to_show = image.copy()
        if img_to_show.dtype != np.uint8:
            if img_to_show.max() <= 1.0 and img_to_show.min() >= 0.0 and img_to_show.dtype in [np.float32, np.float64]:
                img_to_show = (img_to_show * 255).astype(np.uint8)
            else:
                if img_to_show.min() < 0 or img_to_show.max() > 255 or img_to_show.max() > 1.0: # Heuristic for normalization
                     img_to_show = cv2.normalize(img_to_show, None, 0, 255, cv2.NORM_MINMAX, cv2.CV_8U)
                elif img_to_show.dtype != np.uint8 : # Handles cases like CV_32F gradient images not scaled
                    img_to_show = cv2.convertScaleAbs(img_to_show)


        if len(img_to_show.shape) == 3 and img_to_show.shape[2] == 1:
            img_to_show = img_to_show.squeeze(axis=2)
        elif len(img_to_show.shape) == 2: # Ensure grayscale is displayable as grayscale
            pass # Already fine
        elif len(img_to_show.shape) == 3 and img_to_show.shape[2] == 3: # BGR
            pass # Already fine
        else:
            print(f"Warning: Image '{window_name}' has unexpected shape {img_to_show.shape} or dtype {img_to_show.dtype}. Attempting to display.")


        try:
            # Adjust scale factor if image is already very small
            effective_scale_factor = scale_factor
            if img_to_show.shape[0] < 300 or img_to_show.shape[1] < 300:
                effective_scale_factor = 1.0 # Don't shrink small images further

            cv2.imshow(window_name, cv2.resize(img_to_show, None, fx=effective_scale_factor, fy=effective_scale_factor, interpolation=cv2.INTER_AREA))
        except cv2.error as e:
            print(f"OpenCV error displaying '{window_name}': {e}")
            print(f"Image shape: {img_to_show.shape}, dtype: {img_to_show.dtype}, min: {img_to_show.min()}, max: {img_to_show.max()}")


def detect_barcodes_advanced(image_path, params, show_intermediate_steps=False):
    """
    Detects potential barcode regions in an image using advanced morphological operations.
    Focuses on localizing horizontal 1D barcodes.
    """
    print("\n--- Starting Barcode Detection ---")
    print("Parameters in use:")
    for key, value in params.items():
        print(f"  {key}: {value}")
    print("----------------------------------")

    # --- 1. Load and Preprocess Image ---
    image_orig = cv2.imread(image_path)
    if image_orig is None:
        print(f"Error: Image not found at path {image_path}")
        return None, 0

    print(f"Original image dimensions: {image_orig.shape[1]}x{image_orig.shape[0]}")
    image = cv2.resize(image_orig, None, fx=params['resize_fx'], fy=params['resize_fy'], interpolation=cv2.INTER_AREA)
    print(f"Resized image dimensions: {image.shape[1]}x{image.shape[0]}")
    debug_show("1. Resized Original", image, show_intermediate_steps, scale_factor=params.get('debug_display_scale', 0.5))

    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    debug_show("2. Grayscale", gray, show_intermediate_steps, scale_factor=params.get('debug_display_scale', 0.5))

    # Apply CLAHE (Contrast Limited Adaptive Histogram Equalization)
    clahe = cv2.createCLAHE(clipLimit=params['clahe_clip_limit'], tileGridSize=params['clahe_tile_grid_size'])
    gray_clahe = clahe.apply(gray)
    debug_show("2a. CLAHE Applied", gray_clahe, show_intermediate_steps, scale_factor=params.get('debug_display_scale', 0.5))

    # --- 2. Gradient Calculation ---
    gradX = cv2.Sobel(gray_clahe, ddepth=cv2.CV_32F, dx=1, dy=0, ksize=params['sobel_ksize'])
    gradY = cv2.Sobel(gray_clahe, ddepth=cv2.CV_32F, dx=0, dy=1, ksize=params['sobel_ksize'])

    gradient = cv2.subtract(gradX, gradY)
    gradient = cv2.convertScaleAbs(gradient) # Convert to uint8 for subsequent steps
    debug_show("3. Gradient (X-Y)", gradient, show_intermediate_steps, scale_factor=params.get('debug_display_scale', 0.5))

    # --- 3. Blurring and Adaptive Thresholding ---
    blurred_gradient = cv2.GaussianBlur(gradient, params['gradient_blur_ksize'], 0)
    debug_show("4. Blurred Gradient", blurred_gradient, show_intermediate_steps, scale_factor=params.get('debug_display_scale', 0.5))

    thresh = cv2.adaptiveThreshold(blurred_gradient, 255,
                                   cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                   cv2.THRESH_BINARY, # Use THRESH_BINARY_INV if barcodes are dark on light background and gradient is positive
                                   params['adaptive_thresh_block_size'],
                                   params['adaptive_thresh_C'])
    debug_show("5. Adaptive Threshold", thresh, show_intermediate_steps, scale_factor=params.get('debug_display_scale', 0.5))

    # --- 4. Morphological Operations ---
    # Initial Morphological Open to remove small noise elements (salt noise)
    open_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, params['morph_open_ksize'])
    opened = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, open_kernel, iterations=params['morph_open_iterations'])
    debug_show("6a. Morphological Open", opened, show_intermediate_steps, scale_factor=params.get('debug_display_scale', 0.5))

    # Morphological closing to connect barcode bars
    close_kernel_w = params['morph_close_kernel_w']
    close_kernel_h = params['morph_close_kernel_h']
    
    # Ensure kernel dimensions are odd and positive
    close_kernel_w = max(1, close_kernel_w if close_kernel_w % 2 != 0 else close_kernel_w + 1)
    close_kernel_h = max(1, close_kernel_h if close_kernel_h % 2 != 0 else close_kernel_h + 1)
    
    close_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (close_kernel_w, close_kernel_h))
    closed = cv2.morphologyEx(opened, cv2.MORPH_CLOSE, close_kernel)
    debug_show("6b. Morphological Close", closed, show_intermediate_steps, scale_factor=params.get('debug_display_scale', 0.5))

    # Erosions and dilations to refine regions
    # This step can be aggressive. Default iterations reduced.
    if params['erode_dilate_iterations'] > 0:
        closed = cv2.erode(closed, None, iterations=params['erode_dilate_iterations'])
        closed = cv2.dilate(closed, None, iterations=params['erode_dilate_iterations'])
        debug_show("7. Erode & Dilate", closed, show_intermediate_steps, scale_factor=params.get('debug_display_scale', 0.5))
    else:
        debug_show("7. Erode & Dilate (SKIPPED)", closed, show_intermediate_steps, scale_factor=params.get('debug_display_scale', 0.5))


    # --- 5. Contour Detection and Filtering ---
    cnts, hierarchy = cv2.findContours(closed.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    
    if show_intermediate_steps:
        debug_show("Input to findContours (closed_refined)", closed, show_intermediate_steps, scale_factor=params.get('debug_display_scale', 0.5))

    print(f"\nFound {len(cnts)} initial contours after morphological operations.")

    if not cnts:
        print("No initial contours found after morphological operations. This could be due to:")
        print("  - Image quality or barcode visibility issues.")
        print("  - Parameters for adaptive thresholding (block_size, C) not suitable.")
        print("  - Morphological closing kernel (width/height) too small or too large.")
        print("  - Erode/dilate iterations too high, removing all candidates.")
        print("Please review the intermediate images ('5. Adaptive Threshold', '6b. Morphological Close', '7. Erode & Dilate').")
        return image, 0 # Return the resized input image

    if show_intermediate_steps:
        contour_debug_image = image.copy()
        cv2.drawContours(contour_debug_image, cnts, -1, (0, 0, 255), 1) # Draw all initial contours in red
        debug_show("All Initial Contours (Pre-Filter)", contour_debug_image, show_intermediate_steps, scale_factor=params.get('debug_display_scale', 0.5))

    detected_barcodes_boxes = []
    min_area_pixels = params['min_barcode_area_ratio'] * (image.shape[0] * image.shape[1])
    print(f"Minimum barcode area (pixels) for filtering: {min_area_pixels:.2f}")

    filter_stage_counts = {
        "initial": len(cnts), "passed_area": 0, "passed_aspect_ratio": 0,
        "passed_vertices": 0, "passed_solidity": 0, "passed_angle": 0, "passed_all": 0
    }

    if show_intermediate_steps: print("\n--- Contour Processing & Filtering Details ---")

    for i, c in enumerate(cnts):
        contour_area = cv2.contourArea(c)
        
        rect = cv2.minAreaRect(c)
        box_points_float = cv2.boxPoints(rect)
        
        (center_x, center_y), (box_w, box_h), angle_rect = rect
        
        long_side = max(box_w, box_h)
        short_side = min(box_w, box_h)
        aspect_ratio = long_side / float(short_side) if short_side > 1e-5 else 0

        peri = cv2.arcLength(c, True)
        approx = cv2.approxPolyDP(c, params['approx_poly_epsilon_factor'] * peri, True)
        num_vertices = len(approx)

        hull = cv2.convexHull(c)
        hull_area = cv2.contourArea(hull)
        solidity = contour_area / float(hull_area) if hull_area > 1e-5 else 0

        # Angle check for horizontal barcodes
        # angle_rect is in [-90, 0).
        # If box_w > box_h (wide rectangle): angle_rect should be close to 0.
        # If box_h > box_w (tall rectangle from minAreaRect perspective): angle_rect should be close to -90.
        #   This means the longer dimension (box_h) is ~vertical, so the 'width' (box_w) is ~horizontal.
        #   However, we want the BARCODE's longer dimension to be horizontal.
        is_aligned_for_horizontal = False
        if box_w >= box_h: # Width from minAreaRect is the longer side (or square)
            # This is a wide or square region. Its reported angle should be close to 0 for horizontal.
            if abs(angle_rect) <= params['max_angle_deviation']:
                is_aligned_for_horizontal = True
        else: # Height from minAreaRect is the longer side
            # This is a tall region. Its reported angle (for its 'width') should be close to -90 for horizontal.
            if abs(angle_rect - (-90.0)) <= params['max_angle_deviation']:
                is_aligned_for_horizontal = True
        
        if show_intermediate_steps:
            print(f"\nContour {i+1}/{len(cnts)}: Area={contour_area:.2f}")
            print(f"  - MinAreaRect: center=({center_x:.1f},{center_y:.1f}), size=({box_w:.1f},{box_h:.1f}), angle={angle_rect:.1f}")
            print(f"  - Aspect Ratio: {aspect_ratio:.2f} (Filter: [{params['min_aspect_ratio']:.1f}-{params['max_aspect_ratio']:.1f}])")
            print(f"  - Vertices: {num_vertices} (Filter Min: {params['min_vertices_for_rect']})")
            print(f"  - Solidity: {solidity:.2f} (Filter Min: {params['min_solidity']:.2f})")
            print(f"  - Angle (rect): {angle_rect:.1f}, box_w: {box_w:.1f}, box_h: {box_h:.1f} -> Is Horizontal: {is_aligned_for_horizontal} (Angle Dev Filter: {params['max_angle_deviation']})")

        # Filter 1: Area
        if contour_area < min_area_pixels:
            if show_intermediate_steps: print(f"  REJECTED: Area ({contour_area:.2f}) < Min Area ({min_area_pixels:.2f})")
            continue
        filter_stage_counts["passed_area"] += 1
        if show_intermediate_steps: print(f"  PASS: Area")

        # Filter 2: Aspect Ratio
        if not (params['min_aspect_ratio'] <= aspect_ratio <= params['max_aspect_ratio']):
            if show_intermediate_steps: print(f"  REJECTED: Aspect Ratio ({aspect_ratio:.2f}) not in range.")
            continue
        filter_stage_counts["passed_aspect_ratio"] += 1
        if show_intermediate_steps: print(f"  PASS: Aspect Ratio")

        # Filter 3: Polygonal Approximation (Vertices)
        if not (params['min_vertices_for_rect'] <= num_vertices <= params['max_vertices_for_rect']): # Added max vertices
            if show_intermediate_steps: print(f"  REJECTED: Vertices ({num_vertices}) not in [{params['min_vertices_for_rect']}-{params['max_vertices_for_rect']}].")
            continue
        filter_stage_counts["passed_vertices"] += 1
        if show_intermediate_steps: print(f"  PASS: Vertices")

        # Filter 4: Solidity
        if solidity < params['min_solidity']:
            if show_intermediate_steps: print(f"  REJECTED: Solidity ({solidity:.2f}) < Min Solidity ({params['min_solidity']:.2f})")
            continue
        filter_stage_counts["passed_solidity"] += 1
        if show_intermediate_steps: print(f"  PASS: Solidity")

        # Filter 5: Angle
        if not is_aligned_for_horizontal:
            if show_intermediate_steps: print(f"  REJECTED: Orientation not suitable for horizontal barcode.")
            continue
        filter_stage_counts["passed_angle"] += 1
        if show_intermediate_steps: print(f"  PASS: Orientation")
        
        if show_intermediate_steps: print(f"  ===> ACCEPTED Contour {i+1}")
        box_points_int = np.intp(box_points_float)
        detected_barcodes_boxes.append(box_points_int)
        filter_stage_counts["passed_all"] += 1

    print("\n--- Filtering Summary ---")
    print(f"Initial contours found: {filter_stage_counts['initial']}")
    print(f"Passed Area Filter: {filter_stage_counts['passed_area']}")
    print(f"Passed Aspect Ratio Filter: {filter_stage_counts['passed_aspect_ratio']} (from those passing Area)")
    print(f"Passed Vertices Filter: {filter_stage_counts['passed_vertices']} (from those passing Aspect Ratio)")
    print(f"Passed Solidity Filter: {filter_stage_counts['passed_solidity']} (from those passing Vertices)")
    print(f"Passed Angle Filter: {filter_stage_counts['passed_angle']} (from those passing Solidity)")
    print(f"Total potential barcodes found (passed all filters): {filter_stage_counts['passed_all']}")
    
    output_image = image.copy()
    num_detections = 0
    if detected_barcodes_boxes:
        num_detections = len(detected_barcodes_boxes)
        print(f"\nDrawing {num_detections} detected barcode(s) on the image.")
        for box in detected_barcodes_boxes:
            cv2.drawContours(output_image, [box], -1, (0, 255, 0), 2) # Green box
    else:
        print("\nNo contours met all filtering criteria for a barcode.")

    return output_image, num_detections


def main():
    ap = argparse.ArgumentParser(description="Advanced barcode localization using OpenCV morphological operations.")
    ap.add_argument("-i", "--image", required=True, help="Path to the image file")
    ap.add_argument("--show", type=int, default=0, choices=[0, 1],
                        help="Show intermediate processing images (1=yes, 0=no). This also enables verbose terminal output.")
    ap.add_argument("--debug-display-scale", type=float, default=0.5, help="Scale factor for displaying intermediate debug images.")


    # Tunable parameters from the script
    ap.add_argument("--resize-fx", type=float, default=0.7, help="Initial image resize factor for x-axis.")
    ap.add_argument("--resize-fy", type=float, default=0.7, help="Initial image resize factor for y-axis.")
    
    ap.add_argument("--clahe-clip-limit", type=float, default=2.0, help="CLAHE clip limit.")
    ap.add_argument("--clahe-tile-grid-size", type=int, default=8, help="CLAHE tile grid size (single int for NxN).")

    ap.add_argument("--sobel-ksize", type=int, default=-1, help="Sobel gradient kernel size (-1 for Scharr).")
    ap.add_argument("--gradient-blur-ksize-w", type=int, default=5, help="Gaussian blur kernel width for gradient.")
    ap.add_argument("--gradient-blur-ksize-h", type=int, default=5, help="Gaussian blur kernel height for gradient.")
    
    ap.add_argument("--adaptive-thresh-block-size", type=int, default=35, help="Adaptive thresholding block size (odd).")
    ap.add_argument("--adaptive-thresh-C", type=int, default=7, help="Adaptive thresholding constant C.")
    
    ap.add_argument("--morph-open-ksize-w", type=int, default=3, help="Morphological open kernel width.")
    ap.add_argument("--morph-open-ksize-h", type=int, default=3, help="Morphological open kernel height.")
    ap.add_argument("--morph-open-iterations", type=int, default=1, help="Morphological open iterations.")

    ap.add_argument("--morph-close-kernel-w", type=int, default=27, help="Morphological closing kernel width.")
    ap.add_argument("--morph-close-kernel-h", type=int, default=9, help="Morphological closing kernel height.")
    
    ap.add_argument("--erode-dilate-iterations", type=int, default=1, help="Erosion and Dilation iterations (0 to disable).") # Default changed to 1
    
    ap.add_argument("--min-barcode-area-ratio", type=float, default=0.0005, help="Min area as fraction of total image area.")
    ap.add_argument("--min-aspect-ratio", type=float, default=1.8, help="Min aspect ratio (long/short).")
    ap.add_argument("--max-aspect-ratio", type=float, default=15.0, help="Max aspect ratio (long/short).")
    ap.add_argument("--min-vertices-for-rect", type=int, default=4, help="Min vertices for polygonal approximation.")
    ap.add_argument("--max-vertices-for-rect", type=int, default=8, help="Max vertices for polygonal approximation (to filter out complex shapes).") # Added max
    ap.add_argument("--approx-poly-epsilon-factor", type=float, default=0.02, help="Epsilon factor for cv2.approxPolyDP.")
    ap.add_argument("--min-solidity", type=float, default=0.70, help="Minimum solidity of the contour (convex_area / contour_area).")
    ap.add_argument("--max-angle-deviation", type=float, default=10.0, help="Max angle deviation (degrees) for major axis from horizontal.")

    args = ap.parse_args()

    params = {
        'resize_fx': args.resize_fx,
        'resize_fy': args.resize_fy,
        'debug_display_scale': args.debug_display_scale, # Added for debug_show
        'clahe_clip_limit': args.clahe_clip_limit,
        'clahe_tile_grid_size': (args.clahe_tile_grid_size, args.clahe_tile_grid_size),
        'sobel_ksize': args.sobel_ksize,
        'gradient_blur_ksize': (args.gradient_blur_ksize_w if args.gradient_blur_ksize_w % 2 != 0 else args.gradient_blur_ksize_w +1 , 
                                args.gradient_blur_ksize_h if args.gradient_blur_ksize_h % 2 != 0 else args.gradient_blur_ksize_h +1), # Must be odd
        'adaptive_thresh_block_size': args.adaptive_thresh_block_size, # Will be validated below
        'adaptive_thresh_C': args.adaptive_thresh_C,
        'morph_open_ksize': (args.morph_open_ksize_w if args.morph_open_ksize_w % 2 != 0 else args.morph_open_ksize_w+1, 
                             args.morph_open_ksize_h if args.morph_open_ksize_h % 2 != 0 else args.morph_open_ksize_h+1), # Must be odd
        'morph_open_iterations': args.morph_open_iterations,
        'morph_close_kernel_w': args.morph_close_kernel_w, # Will be validated in function
        'morph_close_kernel_h': args.morph_close_kernel_h, # Will be validated in function
        'erode_dilate_iterations': args.erode_dilate_iterations,
        'min_barcode_area_ratio': args.min_barcode_area_ratio,
        'min_aspect_ratio': args.min_aspect_ratio,
        'max_aspect_ratio': args.max_aspect_ratio,
        'min_vertices_for_rect': args.min_vertices_for_rect,
        'max_vertices_for_rect': args.max_vertices_for_rect, # Added
        'approx_poly_epsilon_factor': args.approx_poly_epsilon_factor,
        'min_solidity': args.min_solidity,
        'max_angle_deviation': args.max_angle_deviation
    }

    # Ensure adaptive_thresh_block_size is odd and > 1
    if params['adaptive_thresh_block_size'] <= 1:
        print(f"Warning: adaptive_thresh_block_size ({params['adaptive_thresh_block_size']}) too small, setting to 3.")
        params['adaptive_thresh_block_size'] = 3
    elif params['adaptive_thresh_block_size'] % 2 == 0:
        params['adaptive_thresh_block_size'] +=1
        print(f"Warning: adaptive_thresh_block_size was even, adjusted to {params['adaptive_thresh_block_size']}.")

    # Ensure blur kernel sizes are odd
    for k in ['gradient_blur_ksize', 'morph_open_ksize']:
        w, h = params[k]
        if w % 2 == 0: w += 1
        if h % 2 == 0: h += 1
        params[k] = (max(1,w), max(1,h)) # Ensure positive


    final_image_with_detections, num_detections = detect_barcodes_advanced(
        args.image,
        params,
        show_intermediate_steps=bool(args.show)
    )

    if final_image_with_detections is not None:
        # Determine display scale for final image based on its size
        display_scale_final = 0.8
        if final_image_with_detections.shape[0] > 1000 or final_image_with_detections.shape[1] > 1000:
            display_scale_final = 0.5
        elif final_image_with_detections.shape[0] < 400 or final_image_with_detections.shape[1] < 400:
            display_scale_final = 1.0 # Don't scale down small final images too much
            
        final_window_name = f"Detected Barcode(s) - Final ({num_detections} found)"
        
        # Resize only if necessary for display
        if display_scale_final != 1.0:
            display_img = cv2.resize(final_image_with_detections, None, fx=display_scale_final, fy=display_scale_final, interpolation=cv2.INTER_AREA)
        else:
            display_img = final_image_with_detections
        
        cv2.imshow(final_window_name, display_img)
        
        print("\n--- Displaying Final Result ---")
        if args.show:
            print("Displaying intermediate steps alongside final result.")
            print(f"Press '0' (zero) on any OpenCV window to close all windows.")
        else:
            print(f"Press '0' (zero) on the '{final_window_name}' window to close.")
        
        cv2.waitKey(0)
        cv2.destroyAllWindows()
        print("-------------------------------")
    else:
        print("Error: Barcode detection function returned None for the final image.")

if __name__ == "__main__":
    main()