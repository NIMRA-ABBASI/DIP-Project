import argparse
import cv2
from pyzbar.pyzbar import decode
import numpy as np
import os
from datetime import datetime

# --- Configuration for visual output ---
BARCODE_COLORS = {
    "QRCODE": (0, 0, 255),    # Red for QR Codes
    "EAN13": (0, 255, 0),     # Green for EAN13
    "UPCA": (0, 255, 0),      # Green for UPC-A
    "CODE128": (255, 0, 0),   # Blue for Code128
    "CODE39": (255, 0, 0),    # Blue for Code39
    "ITF": (255, 165, 0),     # Orange for ITF
    "DEFAULT": (255, 255, 0)  # Cyan for others
}
FONT = cv2.FONT_HERSHEY_SIMPLEX
FONT_SCALE_BASE = 0.5
FONT_THICKNESS = 2

def preprocess_image(image, args):
    """
    Applies a series of preprocessing steps to the image to enhance barcode detection.
    Returns a list of images to try decoding on.
    """
    processed_images = {} # Dictionary to store different processed versions

    # 0. Original Resized Grayscale
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    processed_images['gray'] = gray.copy()
    if args.show_intermediate:
        cv2.imshow("0. Grayscale", gray)

    # 1. CLAHE (Contrast Limited Adaptive Histogram Equalization)
    if args.use_clahe:
        clahe = cv2.createCLAHE(clipLimit=args.clahe_clip_limit, tileGridSize=(args.clahe_tile_size, args.clahe_tile_size))
        clahe_gray = clahe.apply(gray)
        processed_images['clahe'] = clahe_gray.copy()
        if args.show_intermediate:
            cv2.imshow("1. CLAHE", clahe_gray)
        current_gray = clahe_gray # Use CLAHE output for subsequent steps if enabled
    else:
        current_gray = gray

    # 2. Gaussian Blur (Optional, can help reduce noise before thresholding)
    if args.blur_ksize > 0:
        blurred = cv2.GaussianBlur(current_gray, (args.blur_ksize, args.blur_ksize), 0)
        processed_images['blurred'] = blurred.copy()
        if args.show_intermediate:
            cv2.imshow("2. Blurred", blurred)
        current_gray_for_thresh = blurred
    else:
        current_gray_for_thresh = current_gray


    # 3. Adaptive Thresholding
    if args.use_adaptive_thresh:
        adaptive_thresh = cv2.adaptiveThreshold(current_gray_for_thresh, 255,
                                                cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                                cv2.THRESH_BINARY,
                                                args.adaptive_thresh_block_size,
                                                args.adaptive_thresh_c)
        processed_images['adaptive_thresh'] = adaptive_thresh.copy()
        if args.show_intermediate:
            cv2.imshow("3a. Adaptive Threshold", adaptive_thresh)
        
        # Inverted adaptive threshold
        adaptive_thresh_inv = cv2.bitwise_not(adaptive_thresh)
        processed_images['adaptive_thresh_inv'] = adaptive_thresh_inv.copy()
        if args.show_intermediate:
            cv2.imshow("3b. Adaptive Threshold Inverted", adaptive_thresh_inv)

    # 4. Global Thresholding (as in original, but now optional)
    if args.use_global_thresh:
        _, global_thresh = cv2.threshold(current_gray_for_thresh, args.global_thresh_val, 255, cv2.THRESH_BINARY)
        processed_images['global_thresh'] = global_thresh.copy()
        if args.show_intermediate:
            cv2.imshow("4a. Global Threshold", global_thresh)

        global_thresh_inv = cv2.bitwise_not(global_thresh)
        processed_images['global_thresh_inv'] = global_thresh_inv.copy()
        if args.show_intermediate:
            cv2.imshow("4b. Global Threshold Inverted", global_thresh_inv)


    # 5. Morphological Operations (Optional, can help 1D barcodes)
    #    Applied to adaptive_thresh if available, otherwise to global_thresh or clahe/gray
    base_for_morph = None
    if 'adaptive_thresh' in processed_images:
        base_for_morph = processed_images['adaptive_thresh']
    elif 'global_thresh' in processed_images:
        base_for_morph = processed_images['global_thresh']
    elif 'clahe' in processed_images: # Fallback to CLAHE if no thresholding done
        # For direct morph on grayscale, might need binarization first or very careful kernel
        _, base_for_morph = cv2.threshold(processed_images['clahe'], 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

    if base_for_morph is not None and args.morph_kernel_size > 0:
        kernel_size = args.morph_kernel_size
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (kernel_size, kernel_size)) # Square kernel
        
        # Closing: Dilate then Erode - good for closing small gaps in bars
        closed = cv2.morphologyEx(base_for_morph, cv2.MORPH_CLOSE, kernel, iterations=args.morph_iterations)
        processed_images['morph_closed'] = closed.copy()
        if args.show_intermediate:
            cv2.imshow("5. Morphological Closing", closed)

        # Opening: Erode then Dilate - good for removing small noise
        opened = cv2.morphologyEx(base_for_morph, cv2.MORPH_OPEN, kernel, iterations=args.morph_iterations)
        processed_images['morph_opened'] = opened.copy()
        if args.show_intermediate:
            cv2.imshow("5b. Morphological Opening", opened)


    # Return a list of images to attempt decoding on, in a preferred order
    # More processed images (like thresholded, morphed) are often better for pyzbar
    decode_attempts = []
    if 'adaptive_thresh' in processed_images: decode_attempts.append(processed_images['adaptive_thresh'])
    if 'adaptive_thresh_inv' in processed_images: decode_attempts.append(processed_images['adaptive_thresh_inv'])
    if 'morph_closed' in processed_images: decode_attempts.append(processed_images['morph_closed'])
    if 'morph_opened' in processed_images: decode_attempts.append(processed_images['morph_opened'])
    if 'global_thresh' in processed_images: decode_attempts.append(processed_images['global_thresh'])
    if 'global_thresh_inv' in processed_images: decode_attempts.append(processed_images['global_thresh_inv'])
    if 'clahe' in processed_images: decode_attempts.append(processed_images['clahe']) # Grayscale after CLAHE
    decode_attempts.append(processed_images['gray']) # Original grayscale as last resort

    # Remove duplicates (if any image ended up being the same due to disabled steps)
    # by converting to bytes and using a set, then back to numpy arrays.
    # This is a bit heavy, a simpler check might be sufficient if performance is critical.
    unique_attempts = []
    seen_hashes = set()
    for img in decode_attempts:
        img_hash = img.tobytes()
        if img_hash not in seen_hashes:
            unique_attempts.append(img)
            seen_hashes.add(img_hash)
            
    return unique_attempts


def decode_barcodes(images_to_try):
    """
    Attempts to decode barcodes from a list of processed images.
    Returns a list of unique decoded objects.
    """
    all_decoded_objects = []
    found_data_hashes = set() # To store hashes of (data, type, rect) to ensure uniqueness

    for i, processed_image in enumerate(images_to_try):
        if processed_image is None: continue
        # print(f"Attempting decode on image variant {i+1}...")
        decoded_here = decode(processed_image)
        
        for obj in decoded_here:
            # Create a unique hash for this detection
            obj_hash = (obj.data, obj.type, obj.rect)
            if obj_hash not in found_data_hashes:
                all_decoded_objects.append(obj)
                found_data_hashes.add(obj_hash)
                
    if not all_decoded_objects:
        print("No barcodes detected after trying all preprocessing variants.")
    else:
        print(f"Found {len(all_decoded_objects)} unique barcode(s) in total.")
        
    return all_decoded_objects


def draw_detections(image, decoded_objects, args):
    """
    Draws bounding boxes and decoded information on the original image.
    """
    output_image = image.copy()
    if not decoded_objects:
        return output_image

    for obj in decoded_objects:
        barcode_type = obj.type
        try:
            barcode_data = obj.data.decode('utf-8')
        except UnicodeDecodeError:
            barcode_data = str(obj.data) # Fallback if not utf-8
            print(f"Warning: Could not decode data as UTF-8 for a {barcode_type}. Data: {barcode_data}")

        print(f'  Format: {barcode_type} | Data: {barcode_data}')

        (x, y, w, h) = obj.rect
        color = BARCODE_COLORS.get(barcode_type, BARCODE_COLORS["DEFAULT"])

        # Draw bounding box
        cv2.rectangle(output_image, (x, y), (x + w, y + h), color, 2)

        # Prepare text
        text = f"{barcode_type}: {barcode_data[:args.max_text_len]}" # Truncate long data
        if len(barcode_data) > args.max_text_len:
            text += "..."

        # Adjust font scale based on barcode width to avoid overly large/small text
        font_scale = min(FONT_SCALE_BASE * (w / 100.0), FONT_SCALE_BASE * 2) # Cap max font scale
        font_scale = max(font_scale, FONT_SCALE_BASE * 0.5) # Min font scale

        # Get text size to position it correctly
        (text_width, text_height), baseline = cv2.getTextSize(text, FONT, font_scale, FONT_THICKNESS)
        
        # Position text above the barcode, ensuring it's within image bounds
        text_y = y - 10
        if text_y - text_height < 0: # If text goes off top, put it inside
            text_y = y + text_height + 5 
        
        text_x = x
        if text_x + text_width > output_image.shape[1]: # If text goes off right
            text_x = output_image.shape[1] - text_width - 5
        text_x = max(text_x, 0) # Ensure text_x is not negative

        # Draw a filled rectangle behind the text for better visibility
        cv2.rectangle(output_image, (text_x, text_y - text_height - baseline//2), 
                      (text_x + text_width, text_y + baseline//2), color, -1)
        cv2.putText(output_image, text, (text_x, text_y), FONT,
                    font_scale, (0,0,0), FONT_THICKNESS, cv2.LINE_AA) # Black text on colored_bg

    return output_image

def main():
    parser = argparse.ArgumentParser(description="Advanced Barcode and QR Code Detection using pyzbar and OpenCV.")
    parser.add_argument("-i", "--image", required=True, help="Path to input image file.")
    parser.add_argument("--resize_fx", type=float, default=1.0, help="Resize factor for image width (default: 1.0, no resize).")
    parser.add_argument("--resize_fy", type=float, default=1.0, help="Resize factor for image height (default: 1.0, no resize).")
    
    # Preprocessing toggles
    parser.add_argument("--use_clahe", action='store_true', help="Enable CLAHE preprocessing.")
    parser.add_argument("--clahe_clip_limit", type=float, default=2.0, help="CLAHE clip limit.")
    parser.add_argument("--clahe_tile_size", type=int, default=8, help="CLAHE tile grid size.")
    
    parser.add_argument("--blur_ksize", type=int, default=0, help="Kernel size for Gaussian blur (e.g., 3, 5). 0 to disable. Must be odd.")

    parser.add_argument("--use_adaptive_thresh", action='store_true', help="Enable adaptive thresholding.")
    parser.add_argument("--adaptive_thresh_block_size", type=int, default=35, help="Block size for adaptive threshold (must be odd).")
    parser.add_argument("--adaptive_thresh_c", type=int, default=5, help="Constant C for adaptive threshold.")

    parser.add_argument("--use_global_thresh", action='store_true', help="Enable global thresholding.")
    parser.add_argument("--global_thresh_val", type=int, default=150, help="Value for global thresholding.")

    parser.add_argument("--morph_kernel_size", type=int, default=0, help="Kernel size for morphological operations (e.g., 3, 5 for closing/opening). 0 to disable.")
    parser.add_argument("--morph_iterations", type=int, default=1, help="Iterations for morphological operations.")

    # Output and Display
    parser.add_argument("--show", action='store_true', help="Show the output image window.")
    parser.add_argument("--show_intermediate", action='store_true', help="Show intermediate preprocessing images.")
    parser.add_argument("--save_output", type=str, default=None, help="Path to save the output image. If None, generates a filename.")
    parser.add_argument("--output_folder", type=str, default="barcode_outputs", help="Folder for automatically named output images.")
    parser.add_argument("--max_text_len", type=int, default=30, help="Maximum length of barcode data text displayed on image.")

    args = parser.parse_args()

    # Validate some arguments
    if args.blur_ksize > 0 and args.blur_ksize % 2 == 0:
        args.blur_ksize +=1
        print(f"Adjusted blur_ksize to be odd: {args.blur_ksize}")
    if args.adaptive_thresh_block_size % 2 == 0:
        args.adaptive_thresh_block_size +=1
        print(f"Adjusted adaptive_thresh_block_size to be odd: {args.adaptive_thresh_block_size}")
    if args.morph_kernel_size > 0 and args.morph_kernel_size % 2 == 0:
        args.morph_kernel_size +=1
        print(f"Adjusted morph_kernel_size to be odd: {args.morph_kernel_size}")


    print("--- Starting Barcode Detection ---")
    try:
        original_image = cv2.imread(args.image)
        if original_image is None:
            raise FileNotFoundError(f"Image not found or could not be read: {args.image}")

        # Resize image
        if args.resize_fx != 1.0 or args.resize_fy != 1.0:
            print(f"Resizing image by fx={args.resize_fx}, fy={args.resize_fy}")
            original_image = cv2.resize(original_image, None, fx=args.resize_fx, fy=args.resize_fy, interpolation=cv2.INTER_CUBIC)
        
        if args.show_intermediate:
             cv2.imshow("Original Resized", original_image)

        images_to_try_decoding = preprocess_image(original_image, args)
        
        print(f"\nAttempting to decode using {len(images_to_try_decoding)} preprocessed image variants...")
        decoded_objects = decode_barcodes(images_to_try_decoding)
        
        output_image_with_detections = draw_detections(original_image, decoded_objects, args)

        if args.save_output is not None or decoded_objects: # Save if path specified or if detections were made
            output_filename = args.save_output
            if output_filename is None: # Auto-generate filename
                if not os.path.exists(args.output_folder):
                    os.makedirs(args.output_folder)
                base, ext = os.path.splitext(os.path.basename(args.image))
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                output_filename = os.path.join(args.output_folder, f"{base}_detected_{timestamp}{ext if ext else '.png'}")
            
            try:
                cv2.imwrite(output_filename, output_image_with_detections)
                print(f"\nOutput image saved to: {output_filename}")
            except Exception as e:
                print(f"Error saving output image: {e}")


        if args.show or (args.show_intermediate and not decoded_objects): # Show final if --show or if intermediate was shown and no detection
            cv2.imshow("Barcode Detection Result", output_image_with_detections)
            print("\nPress any key on an image window to close all windows.")
            cv2.waitKey(0)
        
        print("--- Detection Finished ---")

    except FileNotFoundError as e:
        print(f"Error: {e}")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
    finally:
        cv2.destroyAllWindows()

if __name__ == "__main__":
    main()
    
	#python barcode_detect_and_decode.py -i imgs/result3.png --show
    #python barcode_detect_and_decode.py -i imgs/result3.png --show --show_intermediate
    # python barcode_detect_and_decode.py -i imgs/result3.png --use_clahe --use_adaptive_thresh --show --show_intermediate
    #python barcode_detect_and_decode.py -i imgs/result3.png --use_adaptive_thresh --morph_kernel_size 5 --show                                        